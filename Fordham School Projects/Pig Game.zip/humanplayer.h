// CISC 2000   Fordham University
// Instructor: Vincent Mierlak
// 
// Header file humanplayer.h.
// 
// A derived class for a human player in the game of Pig.

#ifndef HUMANPLAYER_H
#define HUMANPLAYER_H

#include "player.h"


class HumanPlayer : public Player
{
    public:
        HumanPlayer();
        //default constructor

        HumanPlayer(std::string a);
        //construct human player object given the name

        void take_turn();
};

#endif //HUMANPLAYER_H
