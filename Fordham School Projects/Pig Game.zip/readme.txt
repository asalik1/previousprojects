The most difficult part of this assignment for me was using the pointers in 
the piggame.cpp implementation. I was very lost on why I kept getting errors
that said that the Player *winner cannot be assigned to g.play() or when the
cout statement included the output of *winner.

It was only after doing an extensive review on the fundamental rules and 
properties of pointers that I began to somewhat understand what type of return 
is needed for the play() function and what constructors I should add to the 
PigGame class.

After going through the how I should implement the play() function using
pointers, I stumbled on the obstacle of determining on how to output *winner
in the cout statement of line 30 in the main.cpp file. I quickly realized I
needed to overload the out operator, but I still had the same error that
basically said that there was no output operator for a Player object. It was
only after many hours of googling that I realized I had no idea how to tackle
this problem. So I emailed Professor Mierlak, and he helped me understand that
the issue was that the operator overloading functiong should be in the Player
class instead of the PigGame class (thank you professor). With that, it was
only a matter of playing the game repeatedly to make sure there were no logic
errors, and I conclude that there is none from what I tested.

