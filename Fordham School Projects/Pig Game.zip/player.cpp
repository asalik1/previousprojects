// CISC 2000  Fordham University  Spring 2020
// Instructor: Vincent Mierlak
//
// HW 9: The Game of Pig.
// File: player.cpp
//       Implementation of Player, a base class for a player 
//       in the game of Pig.


#include "player.h"
#include "dice.h"

Player::Player()
{
    name = "name";
    total_points = 0;
}

Player::Player(std::string a)
{
    name = a;
    total_points = 0;
}

std::string Player::get_name() const
{
    return name;
}

int Player::get_points() const
{
    return total_points;
}
