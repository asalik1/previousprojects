// CISC 2000   Fordham University
// Instructor: Vincent Mierlak
// 
// Header file player.h.
// 
// A base class for a player in the game of Pig.

#ifndef PLAYER_H
#define PLAYER_H

#include<iostream>

class Player
{
    public:
        Player();
        //default constructor
        
        Player(std::string a);
        //construct object using a name

        virtual void take_turn()
        {
            //intentionally left blank
        }
        //vitual function for taking turns

        std::string get_name() const;
        //returns name of player

        int get_points() const;
        //returns points of player

        friend std::ostream& operator<<(std::ostream &output, const Player& winner)
        {
            output << winner.name;
            return output;
        }
        //overloaded output operator to display name
    protected:
        std::string name;
        //name of player

        int total_points;
        //points of player
};

#endif //PLAYER_H
