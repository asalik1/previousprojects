// CISC 2000  Fordham University  Spring 2020
// Instructor: Vincent Mierlak
//
// HW 9: The Game of Pig.
// File: computerplayer.cpp
//       Implementation of ComputerPlayer, a dervied class for the 
//       computer to play the game of Pig.


#include "computerplayer.h"
#include "dice.h"

ComputerPlayer::ComputerPlayer()
{
    name = "Computer_Player";
    total_points = 0;
}

ComputerPlayer::ComputerPlayer(std::string a)
{
    name = a;
    total_points = 0;
}

void ComputerPlayer::take_turn()
{
    using namespace std;
    bool truth_call = true; //true while the conditions for ending turn are not met
    int temp_points = total_points; //restore points to total points before this turn
    int counter = 0; //counts the number of rolls made by computer player
    int temp; //stores the rolled value
    Dice a(6); //6 sided die

    cout << endl;

    //while conditions for ending turn are not met, continue turn
    while(truth_call && counter < 3)
    {
        temp = a.roll();
        if(temp == 1)
        {
            cout << name << " has rolled a 1. End of turn" << endl;
            total_points = temp_points;
            truth_call = false;

            //end turn since computer rolled a 1
            //restore points to to total points before this turn
        }
        else
        {
            cout << name << " has rolled a " << temp << "." << endl;
            total_points += temp;
            cout << name << " now has " << total_points << " points." << endl;
            counter++;

            //if roll is not 1, add the points to total points
            //then display the total points now
            //add 1 to counter variable to show 1 roll has been done
        }
        if(total_points > 100 || total_points == 100) 
        {
            truth_call = false;
            //if computer as reached 100 points, end turn
        }
    }

    cout << "Total points of " << name << ": " << total_points << endl;
    cout << endl;
}

