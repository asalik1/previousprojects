// CISC 2000   Fordham University
// Instructor: Vincent Mierlak
// 
// Header file piggame.h.
// 
// A class to play the game of Pig.

#ifndef PIGGAME_H
#define PIGGAME_H

#include "dice.h"
#include "player.h"
#include "humanplayer.h"
#include "computerplayer.h"

class PigGame
{
    public:
        PigGame(Player* a, Player* b);
        //set the pointers to point to the player objects that will play

        Player* play();
        //play the game then return the address of the winning player object
    private:
        Player* first_player;
        Player* second_player;
};

#endif // PIGGAME_H
