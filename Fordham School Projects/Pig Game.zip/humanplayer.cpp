// CISC 2000  Fordham University  Spring 2020
// Instructor: Vincent Mierlak
//
// HW 9: The Game of Pig.
// File: humanplayer.cpp
//       Implementation of HumanPlayer, a dervied class for a human player 
//       in the game of Pig.

#include "humanplayer.h"
#include "dice.h"

HumanPlayer::HumanPlayer()
{
    name = "Human";
    total_points = 0;
}

HumanPlayer::HumanPlayer(std::string a)
{
    name = a;
    total_points = 0;
}

void HumanPlayer::take_turn()
{
    using namespace std;
    char choice; //the choice of the user to roll will be matched using chars
    bool truth_call = true; //true while turn ending conditions are not met
    int temp_points = total_points; //stores the total points before turn started
    int temp; //stores the rolled value

    Dice a(6); // 6 sided die

    while(truth_call)
    {
        cout << "Would you like to roll the die? [Y]es or [N]o " << endl;
        cin >> choice;

        if(choice != 'y' && choice != 'Y') 
        {
            truth_call = false; 
            //if user wants to end turn, end loop
        }

        else
        {
            temp = a.roll();
            if(temp == 1)
            {
                cout << name << " has rolled a 1. End of turn."  << endl;
                total_points = temp_points;
                truth_call = false;

                //if user rolls 1, end turn and restore points to what it
                //was before the rolls done in this turn
            }
            else
            {
                cout << name << " has rolled a " << temp << "." << endl;
                total_points += temp;
                cout << name << " has " << total_points << " in total." << endl;

                //if user does not roll 1, add rolled value to total points
                //then display how many points they have now
            }
        }
        if(total_points > 100 || total_points == 100)
        {
            truth_call = false;

            //if user has reached greater than or equal to 100 points,
            //end the loop
        }
    }
    

    cout << "Total Points of " << name << ": " << total_points << endl;
    cout << endl;
}
