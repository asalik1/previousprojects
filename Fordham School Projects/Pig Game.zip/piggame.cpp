// CISC 2000  Fordham University  Spring 2020
// Instructor: Vincent Mierlak
//
// HW 9: The Game of Pig.
// File: piggame.cpp
//       Implementation of PigGame, a class to play a game of Pig.

#include "dice.h"
#include "piggame.h"
#include "player.h"
#include "humanplayer.h"
#include "computerplayer.h"

PigGame::PigGame(Player* a, Player* b)
{
    first_player = a;
    second_player = b;
}

Player* PigGame::play()
{
    using namespace std;
    bool victory_conditions = false;
    //remains false until a player meets the victory conditions

    bool victory_player_one;
    //will be given true or false value depending on whether player one wins
    
    bool victory_player_two;
    //will be given true of false value depending on whether player two wins

    Dice a(2);
    //the 2 sided coin

    
    if(a.roll() < 2) //if coin flip results in one, player one goes first
    {
        while(!victory_conditions)
        {
            first_player -> take_turn();

            cout << "---------------------------------------------------------" << endl;
            cout << "---------------------------------------------------------" << endl;

            if
            (first_player -> get_points() > 100 || first_player -> get_points() == 100)
            {
                victory_conditions = true; //a player has met victory conditions
                victory_player_one = true; //player one is the winner
                victory_player_two = false; //player two is the loser
                break;
            }

            second_player -> take_turn();

            cout << "---------------------------------------------------------" << endl;
            cout << "---------------------------------------------------------" << endl;

            if
            (second_player -> get_points() > 100 || second_player -> get_points() == 100)
            {
                victory_conditions = true; //a player has met victory conditions
                victory_player_one = false; //player one is the loser
                victory_player_two = true; //player two is the winner
                break;
            }
        }
    }
    else
    {
        while(!victory_conditions)
        {
            second_player -> take_turn();

            cout << "---------------------------------------------------------" << endl;
            cout << "---------------------------------------------------------" << endl;

            if
            (second_player -> get_points() > 100 || second_player -> get_points() == 100)
            {
                victory_conditions = true; //a player has met victory conditions
                victory_player_one = false; //player one is the loser
                victory_player_two = true; //player two is the winner
                break;
            }

            first_player -> take_turn();

            cout << "---------------------------------------------------------" << endl;
            cout << "---------------------------------------------------------" << endl;

            if
            (first_player -> get_points() > 100 || first_player -> get_points() == 100)
            {
                victory_conditions = true; //a player has met the victory conditions
                victory_player_one = true; //player one is the winner
                victory_player_two = false; //player two is the loser
                break;
            }
        }
    }

    Player *winner;
    //pointer to point to the address of the player object that won

    if(victory_player_one)
        winner  = first_player; //winner pointer points to first player
    
    if(victory_player_two)
        winner = second_player; //winner pointer points to second player

    return winner; //return address of the winner object

}
